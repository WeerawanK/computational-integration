"""โปรแกรมวาดกราฟสำหรับรายงาน Assignment 3

เขียนเองทั้งหมดด้วย Python standard library ไม่ใช้ library วาดรูปใด ๆ
หลักการคือสร้างภาพขาวดำ (grayscale) เป็นตารางพิกเซลในหน่วยความจำ
วาดเส้น สี่เหลี่ยม วงกลม สามเหลี่ยม และตัวอักษรลงในตารางนั้นเอง
แล้วเขียนออกเป็นไฟล์ PNG ด้วย zlib และ struct
"""

import csv
import io
import statistics
import struct
import zlib
from pathlib import Path

FOLDER = Path(__file__).parent
RESULT_FILE = FOLDER / "results.csv"
CONFIGS = ["8", "16", "8-8", "12-6"]

# -----------------------------------------------------------------------------
# ส่วนที่ 1: ฟอนต์ bitmap ขนาด 5x7 พิกเซล
# -----------------------------------------------------------------------------
# แต่ละตัวอักษรเก็บเป็น 7 แถว แถวละ 5 ตัวอักษร ตัว "1" คือจุดที่ต้องระบายสี
FONT_ROWS = {
    "0": "01110 10001 10011 10101 11001 10001 01110",
    "1": "00100 01100 00100 00100 00100 00100 01110",
    "2": "01110 10001 00001 00010 00100 01000 11111",
    "3": "11110 00001 00001 01110 00001 00001 11110",
    "4": "00010 00110 01010 10010 11111 00010 00010",
    "5": "11111 10000 11110 00001 00001 10001 01110",
    "6": "00110 01000 10000 11110 10001 10001 01110",
    "7": "11111 00001 00010 00100 01000 01000 01000",
    "8": "01110 10001 10001 01110 10001 10001 01110",
    "9": "01110 10001 10001 01111 00001 00010 01100",
    "A": "01110 10001 10001 11111 10001 10001 10001",
    "B": "11110 10001 10001 11110 10001 10001 11110",
    "C": "01110 10001 10000 10000 10000 10001 01110",
    "D": "11100 10010 10001 10001 10001 10010 11100",
    "E": "11111 10000 10000 11110 10000 10000 11111",
    "F": "11111 10000 10000 11110 10000 10000 10000",
    "G": "01110 10001 10000 10111 10001 10001 01111",
    "H": "10001 10001 10001 11111 10001 10001 10001",
    "I": "01110 00100 00100 00100 00100 00100 01110",
    "J": "00111 00010 00010 00010 00010 10010 01100",
    "K": "10001 10010 10100 11000 10100 10010 10001",
    "L": "10000 10000 10000 10000 10000 10000 11111",
    "M": "10001 11011 10101 10101 10001 10001 10001",
    "N": "10001 11001 10101 10011 10001 10001 10001",
    "O": "01110 10001 10001 10001 10001 10001 01110",
    "P": "11110 10001 10001 11110 10000 10000 10000",
    "Q": "01110 10001 10001 10001 10101 10010 01101",
    "R": "11110 10001 10001 11110 10100 10010 10001",
    "S": "01111 10000 10000 01110 00001 00001 11110",
    "T": "11111 00100 00100 00100 00100 00100 00100",
    "U": "10001 10001 10001 10001 10001 10001 01110",
    "V": "10001 10001 10001 10001 10001 01010 00100",
    "W": "10001 10001 10001 10101 10101 10101 01010",
    "X": "10001 10001 01010 00100 01010 10001 10001",
    "Y": "10001 10001 01010 00100 00100 00100 00100",
    "Z": "11111 00001 00010 00100 01000 10000 11111",
    " ": "00000 00000 00000 00000 00000 00000 00000",
    ".": "00000 00000 00000 00000 00000 01100 01100",
    ",": "00000 00000 00000 00000 01100 00100 01000",
    "-": "00000 00000 00000 11111 00000 00000 00000",
    "+": "00000 00100 00100 11111 00100 00100 00000",
    "%": "11001 11010 00010 00100 01000 01011 10011",
    "(": "00010 00100 01000 01000 01000 00100 00010",
    ")": "01000 00100 00010 00010 00010 00100 01000",
    ":": "00000 01100 01100 00000 01100 01100 00000",
    "=": "00000 00000 11111 00000 11111 00000 00000",
    "/": "00001 00001 00010 00100 01000 10000 10000",
}


class Canvas:
    """ผืนผ้าใบขาวดำ วาดที่ความละเอียดสูงกว่าจริง SS เท่า แล้วย่อลงให้ขอบเรียบ"""

    def __init__(self, width, height, ss=3):
        self.width = width
        self.height = height
        self.ss = ss
        # หนึ่งแถวของภาพคือ bytearray ค่า 255 คือสีขาว 0 คือสีดำ
        self.rows = [bytearray([255]) * (width * ss) for _ in range(height * ss)]

    def _clip(self, value, limit):
        return max(0, min(limit, value))

    def fill_rect(self, x0, y0, x1, y1, shade):
        """ระบายสี่เหลี่ยมทึบด้วยระดับสี shade (0 = ดำ, 255 = ขาว)"""
        s = self.ss
        ix0 = self._clip(int(round(min(x0, x1) * s)), self.width * s)
        ix1 = self._clip(int(round(max(x0, x1) * s)), self.width * s)
        iy0 = self._clip(int(round(min(y0, y1) * s)), self.height * s)
        iy1 = self._clip(int(round(max(y0, y1) * s)), self.height * s)
        if ix1 <= ix0:
            return
        block = bytes([shade]) * (ix1 - ix0)
        for y in range(iy0, iy1):
            self.rows[y][ix0:ix1] = block

    def hatch_rect(self, x0, y0, x1, y1, shade, period=9):
        """ระบายลายเส้นเฉียงในสี่เหลี่ยม ใช้แทนสีเพื่อให้แยกแท่งกราฟได้เมื่อพิมพ์ขาวดำ"""
        s = self.ss
        ix0 = self._clip(int(round(x0 * s)), self.width * s)
        ix1 = self._clip(int(round(x1 * s)), self.width * s)
        iy0 = self._clip(int(round(y0 * s)), self.height * s)
        iy1 = self._clip(int(round(y1 * s)), self.height * s)
        gap = period * s
        thick = max(2, s)
        for y in range(iy0, iy1):
            row = self.rows[y]
            for x in range(ix0, ix1):
                if (x + y) % gap < thick:
                    row[x] = shade

    def dot(self, x, y, size, shade):
        """ระบายจุดสี่เหลี่ยมเล็ก ๆ ตรงตำแหน่ง (x, y) ในหน่วยพิกเซลจริง"""
        half = size / 2.0
        self.fill_rect(x - half, y - half, x + half, y + half, shade)

    def line(self, x0, y0, x1, y1, width=2, shade=0, dash=None):
        """วาดเส้นตรงโดยไล่วางจุดตามความยาวเส้น dash = (ยาว, ช่องว่าง) ถ้าต้องการเส้นประ"""
        length = max(abs(x1 - x0), abs(y1 - y0))
        steps = max(1, int(length * self.ss * 1.5))
        for i in range(steps + 1):
            t = i / steps
            if dash is not None:
                position = (t * ((x1 - x0) ** 2 + (y1 - y0) ** 2) ** 0.5) % (dash[0] + dash[1])
                if position > dash[0]:
                    continue
            self.dot(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, width, shade)

    def polygon(self, points, shade):
        """ระบายรูปหลายเหลี่ยมด้วยวิธี scanline หาจุดตัดของเส้นขอบกับแต่ละแถว"""
        s = self.ss
        pts = [(x * s, y * s) for x, y in points]
        top = int(min(p[1] for p in pts))
        bottom = int(max(p[1] for p in pts))
        for y in range(max(0, top), min(self.height * s, bottom + 1)):
            crossings = []
            for i in range(len(pts)):
                xa, ya = pts[i]
                xb, yb = pts[(i + 1) % len(pts)]
                if (ya <= y < yb) or (yb <= y < ya):
                    crossings.append(xa + (y - ya) * (xb - xa) / (yb - ya))
            crossings.sort()
            for k in range(0, len(crossings) - 1, 2):
                a = self._clip(int(crossings[k]), self.width * s)
                b = self._clip(int(crossings[k + 1]), self.width * s)
                if b > a:
                    self.rows[y][a:b] = bytes([shade]) * (b - a)

    def circle(self, cx, cy, radius, shade):
        """วงกลมทึบ ใช้สมการ x^2 + y^2 <= r^2 ตรวจทีละแถว"""
        s = self.ss
        r = radius * s
        for y in range(int(cy * s - r), int(cy * s + r) + 1):
            if 0 <= y < self.height * s:
                dx = (r * r - (y - cy * s) ** 2)
                if dx >= 0:
                    half = dx ** 0.5
                    a = self._clip(int(cx * s - half), self.width * s)
                    b = self._clip(int(cx * s + half), self.width * s)
                    if b > a:
                        self.rows[y][a:b] = bytes([shade]) * (b - a)

    def marker(self, kind, x, y, size, shade):
        """จุดสัญลักษณ์ของแต่ละเส้นกราฟ ใช้รูปร่างต่างกันเพื่อแยกเส้นเมื่อไม่มีสี"""
        r = size / 2.0
        if kind == 0:
            self.circle(x, y, r, shade)
        elif kind == 1:
            self.fill_rect(x - r, y - r, x + r, y + r, shade)
        elif kind == 2:
            self.polygon([(x, y - r * 1.2), (x - r * 1.1, y + r * 0.9), (x + r * 1.1, y + r * 0.9)], shade)
        else:
            self.polygon([(x, y - r * 1.3), (x + r * 1.3, y), (x, y + r * 1.3), (x - r * 1.3, y)], shade)

    def text_width(self, text, scale):
        """ความกว้างของข้อความเมื่อใช้ตัวอักษรขยาย scale เท่า (หนึ่งตัว 5 จุด + เว้น 1 จุด)"""
        return len(text) * 6 * scale - scale

    def text(self, x, y, text, scale=3, shade=0, vertical=False):
        """เขียนข้อความตั้งแต่มุมซ้ายบน (x, y) ถ้า vertical จะหมุนอ่านจากล่างขึ้นบน"""
        cursor = 0
        for char in text.upper():
            rows = FONT_ROWS.get(char, FONT_ROWS[" "]).split()
            for r in range(7):
                for c in range(5):
                    if rows[r][c] == "1":
                        if vertical:
                            px = x + r * scale
                            py = y - (cursor + c) * scale
                            self.fill_rect(px, py - scale, px + scale, py, shade)
                        else:
                            px = x + (cursor + c) * scale
                            py = y + r * scale
                            self.fill_rect(px, py, px + scale, py + scale, shade)
            cursor += 6
        return cursor * scale

    def centered_text(self, cx, y, text, scale=3, shade=0, background=False):
        """ข้อความกึ่งกลางที่ cx ถ้า background เป็น True จะรองพื้นขาวไว้ก่อนเพื่อไม่ให้ทับเส้นกริด"""
        width = self.text_width(text, scale)
        if background:
            self.fill_rect(cx - width / 2.0 - 4, y - 3, cx + width / 2.0 + 4, y + 7 * scale + 3, 255)
        self.text(cx - width / 2.0, y, text, scale, shade)

    def save_png(self, path):
        """ย่อภาพจาก SS เท่าเหลือขนาดจริงด้วยการเฉลี่ยพิกเซล แล้วเขียนไฟล์ PNG"""
        s = self.ss
        raw = bytearray()
        for oy in range(self.height):
            block = self.rows[oy * s:(oy + 1) * s]
            column_sums = [sum(values) for values in zip(*block)]
            raw.append(0)
            for ox in range(self.width):
                raw.append(sum(column_sums[ox * s:(ox + 1) * s]) // (s * s))

        def chunk(kind, payload):
            body = kind + payload
            return struct.pack(">I", len(payload)) + body + struct.pack(">I", zlib.crc32(body) & 0xFFFFFFFF)

        header = struct.pack(">IIBBBBB", self.width, self.height, 8, 0, 0, 0, 0)
        png = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", header) + chunk(b"IDAT", zlib.compress(bytes(raw), 9)) + chunk(b"IEND", b"")
        Path(path).write_bytes(png)


# -----------------------------------------------------------------------------
# ส่วนที่ 2: อ่านผลการทดลองจาก results.csv
# -----------------------------------------------------------------------------
def load_results():
    """อ่านเฉพาะส่วนผลราย fold ของ results.csv (ก่อนบรรทัดคำว่า summary)"""
    text = RESULT_FILE.read_text(encoding="utf-8")
    detail = text.split("summary")[0].strip()
    return list(csv.DictReader(io.StringIO(detail)))


def column(rows, config, name):
    return [float(r[name]) * 100 for r in rows if r["configuration"] == config]


# -----------------------------------------------------------------------------
# ส่วนที่ 3: ฟังก์ชันวาดแกนและกราฟชนิดต่าง ๆ
# -----------------------------------------------------------------------------
LEFT, RIGHT, TOP, BOTTOM = 150, 40, 100, 120
GRAY_SHADES = [60, 130, 190, 225]


class Axes:
    """เก็บขอบเขตกราฟและแปลงค่าข้อมูลเป็นตำแหน่งพิกเซล"""

    def __init__(self, canvas, y_min, y_max, y_step, y_title, x_title):
        self.c = canvas
        self.y_min, self.y_max = y_min, y_max
        self.x0, self.x1 = LEFT, canvas.width - RIGHT
        self.y0, self.y1 = canvas.height - BOTTOM, TOP
        c = canvas
        # เส้นตารางแนวนอนเป็นเส้นประสีเทาอ่อน พร้อมตัวเลขกำกับแกน y
        value = y_min
        while value <= y_max + 1e-9:
            py = self.py(value)
            if value > y_min:
                c.line(self.x0, py, self.x1, py, 1, 200, dash=(6, 6))
            label = str(int(value)) if float(value).is_integer() else str(value)
            c.text(self.x0 - 14 - c.text_width(label, 3), py - 10, label, 3)
            c.line(self.x0 - 8, py, self.x0, py, 2, 0)
            value += y_step
        c.line(self.x0, self.y0, self.x1, self.y0, 3, 0)
        c.line(self.x0, self.y0, self.x0, self.y1, 3, 0)
        c.text(40, (self.y0 + self.y1) / 2 + c.text_width(y_title, 3) / 2, y_title, 3, 0, vertical=True)
        c.centered_text((self.x0 + self.x1) / 2, c.height - 38, x_title, 3)

    def py(self, value):
        return self.y0 - (value - self.y_min) / (self.y_max - self.y_min) * (self.y0 - self.y1)

    def category_center(self, index, count):
        width = (self.x1 - self.x0) / count
        return self.x0 + width * (index + 0.5)


def legend(canvas, entries):
    """วาดคำอธิบายสัญลักษณ์เรียงแนวนอนในแถบด้านบนของกราฟ entries = [(ชื่อ, ฟังก์ชันวาดตัวอย่าง)]"""
    gap = 40
    widths = [canvas.text_width(name, 3) + 70 for name, _ in entries]
    x = (canvas.width - (sum(widths) + gap * (len(widths) - 1))) / 2
    y = 22
    for (name, sample), width in zip(entries, widths):
        sample(x, y, x + 52, y + 22)
        canvas.text(x + 64, y + 1, name, 3)
        x += width + gap


def bar_chart(path, groups, series_names, y_range, y_title, x_title, errors=None, baseline=None):
    """กราฟแท่งแบบกลุ่ม groups[i][j] = ค่าของกลุ่ม i แท่งที่ j (หน่วยเป็น %)"""
    canvas = Canvas(1000, 680)
    ax = Axes(canvas, y_range[0], y_range[1], y_range[2], y_title, x_title)
    count = len(groups)
    per_group = len(series_names)
    slot = (ax.x1 - ax.x0) / count
    bar_width = slot * 0.7 / per_group
    labels = []
    for i, values in enumerate(groups):
        start = ax.category_center(i, count) - bar_width * per_group / 2
        for j, value in enumerate(values):
            bx0 = start + j * bar_width
            top = ax.py(value)
            canvas.fill_rect(bx0, top, bx0 + bar_width, ax.y0, GRAY_SHADES[j] if per_group > 1 else 150)
            if j % 2 == 1:
                canvas.hatch_rect(bx0, top, bx0 + bar_width, ax.y0, 0)
            canvas.line(bx0, top, bx0 + bar_width, top, 2, 0)
            canvas.line(bx0, top, bx0, ax.y0, 2, 0)
            canvas.line(bx0 + bar_width, top, bx0 + bar_width, ax.y0, 2, 0)
            label_y = top - 30
            if errors is not None:
                cx = bx0 + bar_width / 2
                upper, lower = ax.py(value + errors[i][j]), ax.py(value - errors[i][j])
                canvas.line(cx, upper, cx, lower, 3, 0)
                canvas.line(cx - 12, upper, cx + 12, upper, 3, 0)
                canvas.line(cx - 12, lower, cx + 12, lower, 3, 0)
                label_y = upper - 30
            text = ("%.2f" if per_group == 1 else "%.1f") % value
            labels.append((bx0 + bar_width / 2, label_y, text))
        canvas.centered_text(ax.category_center(i, count), ax.y0 + 16, CONFIGS[i], 3)
    for lx, ly, text in labels:
        canvas.centered_text(lx, ly, text, 3, background=True)
    if baseline is not None:
        py = ax.py(baseline[0])
        canvas.line(ax.x0, py, ax.x1, py, 3, 0, dash=(14, 8))
        canvas.fill_rect(ax.x1 - canvas.text_width(baseline[1], 3) - 24, py - 40, ax.x1, py - 8, 255)
        canvas.text(ax.x1 - canvas.text_width(baseline[1], 3) - 12, py - 34, baseline[1], 3)
    if per_group > 1:
        def swatch(j):
            def draw(a, b, c, d):
                canvas.fill_rect(a, b, c, d, GRAY_SHADES[j])
                if j % 2 == 1:
                    canvas.hatch_rect(a, b, c, d, 0)
                canvas.line(a, b, c, b, 2, 0)
                canvas.line(a, d, c, d, 2, 0)
                canvas.line(a, b, a, d, 2, 0)
                canvas.line(c, b, c, d, 2, 0)
            return draw
        legend(canvas, [(name, swatch(j)) for j, name in enumerate(series_names)])
    canvas.save_png(path)


def line_chart(path, series, y_range, y_title, x_title):
    """กราฟเส้นของผลราย fold series = {ชื่อ: [ค่าของ fold 1..10]}"""
    canvas = Canvas(1000, 680)
    ax = Axes(canvas, y_range[0], y_range[1], y_range[2], y_title, x_title)
    dashes = [None, (16, 8), (4, 6), (16, 6)]
    shades = [0, 60, 100, 30]
    folds = 10
    for index in range(folds):
        cx = ax.x0 + (ax.x1 - ax.x0) * (index + 0.5) / folds
        label = str(index + 1)
        canvas.centered_text(cx, ax.y0 + 16, label, 3)
        canvas.line(cx, ax.y0, cx, ax.y0 + 8, 2, 0)
    entries = []
    for k, (name, values) in enumerate(series.items()):
        points = [(ax.x0 + (ax.x1 - ax.x0) * (i + 0.5) / folds, ax.py(v)) for i, v in enumerate(values)]
        for a, b in zip(points, points[1:]):
            canvas.line(a[0], a[1], b[0], b[1], 3, shades[k], dash=dashes[k])
        for px, py in points:
            canvas.marker(k, px, py, 16, shades[k])
        def sample(a, b, c, d, k=k):
            canvas.line(a, (b + d) / 2, c, (b + d) / 2, 3, shades[k], dash=dashes[k])
            canvas.marker(k, (a + c) / 2, (b + d) / 2, 14, shades[k])
        entries.append((name, sample))
    legend(canvas, entries)
    canvas.save_png(path)


def box(canvas, cx, cy, width, height, lines, scale=3):
    """กล่องสี่เหลี่ยมในผังงาน ข้อความหลายบรรทัดจัดกึ่งกลางกล่อง"""
    x0, y0, x1, y1 = cx - width / 2, cy - height / 2, cx + width / 2, cy + height / 2
    canvas.fill_rect(x0, y0, x1, y1, 240)
    for a, b, c, d in [(x0, y0, x1, y0), (x0, y1, x1, y1), (x0, y0, x0, y1), (x1, y0, x1, y1)]:
        canvas.line(a, b, c, d, 3, 0)
    line_height = 7 * scale + 9
    top = cy - (len(lines) * line_height - 9) / 2
    for i, text in enumerate(lines):
        canvas.centered_text(cx, top + i * line_height, text, scale)


def arrow(canvas, x0, y0, x1, y1):
    """ลูกศร ประกอบด้วยเส้นตรงและหัวสามเหลี่ยมที่ปลายทาง"""
    canvas.line(x0, y0, x1, y1, 3, 0)
    dx, dy = x1 - x0, y1 - y0
    length = (dx * dx + dy * dy) ** 0.5
    ux, uy = dx / length, dy / length
    base = (x1 - ux * 20, y1 - uy * 20)
    canvas.polygon([(x1, y1), (base[0] - uy * 9, base[1] + ux * 9), (base[0] + uy * 9, base[1] - ux * 9)], 0)


def flow_chart(path):
    """ผังงานขั้นตอนการฝึก MLP ด้วย GA หนึ่ง fold"""
    canvas = Canvas(900, 1010)
    cx, width, height, gap = 380, 680, 110, 44
    steps = [
        ["CREATE 16 RANDOM CHROMOSOMES", "(ALL WEIGHTS AND BIASES)"],
        ["DECODE EACH CHROMOSOME TO MLP", "FITNESS = ACCURACY - 0.05 MSE", "(TRAINING SET ONLY)"],
        ["KEEP THE 2 BEST (ELITISM)"],
        ["TOURNAMENT SELECTION (SIZE 3)", "ARITHMETIC CROSSOVER", "GAUSSIAN MUTATION (RATE 0.08)"],
        ["NEW POPULATION OF 16"],
        ["AFTER 20 GENERATIONS: TEST THE BEST", "CHROMOSOME ON THE HELD-OUT FOLD"],
    ]
    top = 70
    centers = []
    for i, lines in enumerate(steps):
        cy = top + height / 2 + i * (height + gap)
        centers.append(cy)
        box(canvas, cx, cy, width, height, lines)
        if i > 0:
            arrow(canvas, cx, centers[i - 1] + height / 2, cx, cy - height / 2)
    loop_x = cx + width / 2 + 60
    canvas.line(cx + width / 2, centers[4], loop_x, centers[4], 3, 0)
    canvas.line(loop_x, centers[4], loop_x, centers[1], 3, 0)
    arrow(canvas, loop_x, centers[1], cx + width / 2, centers[1])
    label = "NEXT GENERATION"
    canvas.text(loop_x + 22, (centers[1] + centers[4]) / 2 + canvas.text_width(label, 3) / 2, label, 3, 0, vertical=True)
    canvas.save_png(path)


def main():
    rows = load_results()
    means = {c: statistics.mean(column(rows, c, "test_accuracy")) for c in CONFIGS}
    sds = {c: statistics.stdev(column(rows, c, "test_accuracy")) for c in CONFIGS}
    out = FOLDER / "figures"
    out.mkdir(exist_ok=True)

    # สัดส่วนของ class ที่พบมากที่สุด (benign 357 จาก 569) ใช้เป็นเส้นเปรียบเทียบพื้นฐาน
    majority = 357 / 569 * 100
    bar_chart(out / "fig_mean_accuracy.png", [[means[c]] for c in CONFIGS], ["TEST ACCURACY"],
              (60, 100, 10), "MEAN TEST ACCURACY (%)", "CONFIGURATION (HIDDEN NODES)",
              errors=[[sds[c]] for c in CONFIGS], baseline=(majority, "ALWAYS PREDICT B: %.1f%%" % majority))

    line_chart(out / "fig_accuracy_by_fold.png", {c: column(rows, c, "test_accuracy") for c in CONFIGS},
               (70, 100, 5), "TEST ACCURACY (%)", "FOLD")

    bar_chart(out / "fig_sensitivity_specificity.png",
              [[statistics.mean(column(rows, c, "test_sensitivity")), statistics.mean(column(rows, c, "test_specificity"))] for c in CONFIGS],
              ["SENSITIVITY", "SPECIFICITY"], (75, 100, 5), "MEAN OVER 10 FOLDS (%)", "CONFIGURATION (HIDDEN NODES)")

    bar_chart(out / "fig_train_test.png",
              [[statistics.mean(column(rows, c, "train_accuracy")), means[c]] for c in CONFIGS],
              ["TRAIN", "TEST"], (86, 96, 2), "MEAN ACCURACY (%)", "CONFIGURATION (HIDDEN NODES)")

    flow_chart(out / "fig_ga_flow.png")
    print("สร้างกราฟครบทุกรูปที่:", out)


if __name__ == "__main__":
    main()
